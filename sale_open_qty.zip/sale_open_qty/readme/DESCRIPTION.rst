This module allows sale users to identify what are the sale orders
that currently have quantities pending to invoice or to ship.
