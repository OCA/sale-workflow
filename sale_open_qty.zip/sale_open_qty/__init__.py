# Copyright 2017 Eficent Business and IT Consulting Services S.L.
#   (http://www.eficent.com)
# Copyright 2020 openindustry.it
#   (https://openindustry.it)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import models
from .init_hook import pre_init_hook
